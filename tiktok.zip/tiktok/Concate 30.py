import os
import subprocess

# Specify the video directory path
video_dir = r"/root/tiktok/video"

# Specify the audio directory path
audio_dir = r"/root/tiktok/audio"

# Create the "Result" folder if it doesn't exist
result_folder = os.path.join(video_dir, "Result")
os.makedirs(result_folder, exist_ok=True)

# Loop through all video files in the video directory
for video_filename in os.listdir(video_dir):
    if video_filename.endswith(".mp4"):
        # Construct full paths
        video_path = os.path.join(video_dir, video_filename)
        video_name = os.path.splitext(video_filename)[0]
        output_path = os.path.join(result_folder, f"{video_name}_output.mp4")

        # Use FFmpeg to perform operations on each video file
        subprocess.run([
            "ffmpeg",
            "-i", video_path,
            "-i", os.path.join(audio_dir, "audio1.mp3"),
            "-filter_complex", "[1:a]volume=1[a1];[a1]concat=n=1:v=0:a=1[outa]",
            "-map", "0:v:0",
            "-map", "[outa]",
            "-t", "600",
            output_path
        ])

        # Remove the input video file after rendering
        # os.remove(video_path)

        print(f"Video and audio have been combined into {output_path}, and the input video has been deleted.")
